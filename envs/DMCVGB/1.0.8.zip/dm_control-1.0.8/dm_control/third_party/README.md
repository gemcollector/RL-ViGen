# Third-party assets

This directory contains third-party assets which are licensed separately to the
the rest of `dm_control`. Please see the LICENSE files within the individual
subpackages for further details.
